import React, { useEffect, useState } from 'react';
import Header from './Header';
import GalleryLists from './GalleryLists';
import {useSelector, useDispatch} from 'react-redux';
import { fetchSearchLists, sortLists } from './redux/gallery/searchActions';
import './Gallery.css';
import { BottomScrollListener } from 'react-bottom-scroll-listener';

const IMAGE_TO_SHOW = 20;

const Gallery = () => {
    const [searchInput, setSearchInput] = useState('');
    const [next, setNext] = useState(IMAGE_TO_SHOW);
    const dispatch = useDispatch();
    const lists = useSelector(state => state?.search?.lists);
    const finalLists = lists?.slice(0, next);

    const handleChange = (e) => {
        setSearchInput(e.target.value);
    }

    const handleKeyDown = (e) => {
        if(e.keyCode === 13){
            dispatch(fetchSearchLists(searchInput));
            setNext(IMAGE_TO_SHOW);
        }
    }

    const handleSort = (e) => {
        const sortValue = e.target.value;
        if(sortValue) {
            const sortedLists = [...finalLists].sort((x, y) => x[sortValue] > y[sortValue] ? 1 : -1);
            dispatch(sortLists(sortedLists));
        }
    }

    const handleClear = () => {
        setSearchInput('');
    }

    const handleMoreImage = () => {
        setNext(next + IMAGE_TO_SHOW);
    };

    useEffect(() => {
        if(!searchInput) dispatch(fetchSearchLists(searchInput));
    }, [searchInput, dispatch]);

  return (
    <div className='gallery'>
        <Header 
            searchInput={searchInput}
            handleChange={handleChange} 
            handleKeyDown={handleKeyDown}
            handleSort={handleSort}
            handleClear={handleClear}
        />
        <GalleryLists 
            searchLists={finalLists} 
        />
        <BottomScrollListener onBottom={handleMoreImage} />
    </div>
  )
}

export default Gallery