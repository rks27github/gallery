import React from 'react';
import './GalleryList.css';

const GalleryList = ({list, handleClick}) => {
    const {id, tags, webformatURL} = list;
  return (
    <div className='list'>
        <img src={webformatURL} alt={tags} onClick={() => handleClick(id)}/>
    </div>
  )
}

export default GalleryList