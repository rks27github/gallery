import axios from "axios";
import { FETCH_SEARCH_FAILURE, FETCH_SEARCH_REQUEST, FETCH_SEARCH_SUCCESS, SORT_LISTS } from "./searchTypes";

const API_KEY = process.env.REACT_APP_API_KEY;

export const fetchSearchRequest = () => {
    return {
        type: FETCH_SEARCH_REQUEST
    }
}

export const fetchSearchSuccess = lists => {
    return {
        type: FETCH_SEARCH_SUCCESS,
        payload: lists
    }
}

export const fetchSearchFailure = error => {
    return {
        type: FETCH_SEARCH_FAILURE, 
        payload: error
    }
}

export const fetchSearchLists = (searchInput) => {
    return (dispatch) => {
        dispatch(fetchSearchRequest());
        axios.get(`https://pixabay.com/api/?key=${API_KEY}&q=${encodeURIComponent(searchInput)}&image_type=photo&safesearch=true&per_page=200`)
        .then(response => {
            const lists = response?.data?.hits;
            dispatch(fetchSearchSuccess(lists));
        })
        .catch(error => {
            const errorMsg = error.message;
            dispatch(fetchSearchFailure(errorMsg));
        })
    }
}

export const sortLists = sortedLists => {
    return {
        type: SORT_LISTS,
        payload:sortedLists
    }
}