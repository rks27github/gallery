import { FETCH_SEARCH_FAILURE, FETCH_SEARCH_REQUEST, FETCH_SEARCH_SUCCESS, SORT_LISTS } from "./searchTypes"

const initialState = {
    loading: false,
    lists: [],
    error: ''
}

const searchReducer = (state = initialState, action) => {
    switch(action.type) {
        case FETCH_SEARCH_REQUEST:
            return {
                ...state,
                loading: true
            }
        case FETCH_SEARCH_SUCCESS:
        return {
            ...state,
            loading: false,
            lists: action.payload,
            error: ''
        }
        case FETCH_SEARCH_FAILURE:
        return {
            ...state,
            loading: false,
            lists: [],
            error: action.payload
        }
        case SORT_LISTS:
        return {
            ...state,
            loading: false,
            lists: action.payload,
            error: ''
        }
        default: return state;
            
    }
}

export default searchReducer;