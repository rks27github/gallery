import { combineReducers } from "@reduxjs/toolkit";
import searchReducer from "./gallery/searchReducer";

const rootReducer = combineReducers({
    search: searchReducer
});

export default rootReducer;