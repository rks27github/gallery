import React from 'react';
import './GalleryListDetail.css';

const GalleryListDetail = ({selectedList, handleClick}) => {
    if(!selectedList?.id) return null;
  return (
    <div className='gallery-list-detail'>
        <button onClick={() => handleClick(null)}>X</button>
        <img src={selectedList?.webformatURL} alt={selectedList?.tags}/>
        <div className='gallery-details'>
            <p>Views: {selectedList?.views}</p>
            <p>Likes: {selectedList?.likes}</p>
            <p>Comments: {selectedList?.comments}</p>
            <div className='gallery-user'>
                <p>User: {selectedList?.user.charAt(0)?.toUpperCase() + selectedList?.user.slice(1)}</p>
                <p className='img'><img src={selectedList?.userImageURL} alt='user-pic' /></p>
            </div>
        </div>
    </div>
  )
}

export default GalleryListDetail