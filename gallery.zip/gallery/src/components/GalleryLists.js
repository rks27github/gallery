import React, { useState } from 'react'
import GalleryList from './GalleryList';
import GalleryListDetail from './GalleryListDetail';
import './GalleryLists.css';

const GalleryLists = ({searchLists}) => {
  const [selectedList, setSelectedList] = useState(null);
  const handleClick = (id) => {
    const listFound = searchLists.find(list => list.id === id);
    setSelectedList(listFound);
  }
  return (
    <div className='gallery-lists'>
      <div className='gallery-lists-container'>
        {searchLists.map((list, id) => (
          <GalleryList 
            key={id} 
            list={list}
            handleClick={handleClick}
          />
        ))}
      </div>
      <div className='gallery-details-container'>
        <GalleryListDetail selectedList={selectedList} handleClick={handleClick}/>
      </div>
    </div>
  )
}

export default GalleryLists