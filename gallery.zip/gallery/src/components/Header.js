import React from 'react';
import './Header.css';

const Header = ({searchInput, handleChange, handleClear, handleKeyDown, handleSort}) => {
  return (
    <div className='gallery-header'>
        <div className='logo'>
            <h1>Rahul's Gallery</h1>
        </div>
        <div className='search-box'>
            <input type="text" placeholder='Search for an image' value={searchInput} onChange={handleChange} onKeyDown={handleKeyDown}/>
            { searchInput && <button onClick={handleClear}>X</button>}
        </div>
        <div className='sort-by'>
            <select onChange={handleSort}>
                <option value=''>Sort By</option>
                <option value="views">Views</option>
                <option value="imageSize">Image Size</option>
            </select>
        </div>
    </div>
  )
}

export default Header